Requirements
============
- jumper cap for the TP12 pins on the card
- FreeDOS boot stick created with Rufus
- UEFI version of sas3flash (sas3flash.efi)
- LSI IT mode firmware v16.00.12.00 or higher matching the Intel RS3UC080 (SAS9300_8i_IT.bin)
- LSI IT mode firmware with a short lowercase name ("it.bin" --> identical to "SAS9300_8i_IT.bin")
- (optional) boot ROMs (mptsas3.rom + mpt3x64.rom --> only necessary if you plan on booting from drives connected to the card)

You can find all the necessary files in the "Intel_RS3UC080_IT_mode_flash_files.7z" archive.



Preparations
============

1. Prepare the FreeDOS boot stick using Rufus.

2. Extract the "Intel_RS3UC080_IT_mode_flash_files.7z" archive and copy all the contents to the root of the FreeDOS boot stick.

3. Disconnect all drives from to the card.



Instructions
============
If at any point of the instructions you get the message "Controller is not operational. A firmware download is required.", write "it.bin" in the input field and hit ENTER.

1. Boot the system to the EFI shell and navigate to the root of your boot stick.

2. Backup the stock information of the card. Also take a picture of the output in order to add back the SAS address later on.
sas3flash.efi -list -l stock_flash.txt

Adapter Selected is a Avago SAS: SAS3008(C0)

Controller Number              : 0
Controller                     : SAS3008(C0)
PCI Address                    : 00:00:10:00
SAS Address                    : XXXXXXX-X-XXXX-XXXX (redacted)
NVDATA Version (Default)       : 04.05.00.04
NVDATA Version (Persistent)    : 04.05.00.04
Firmware Product ID            : 0x2721 (IR)
Firmware Version               : 04.00.03.00
NVDATA Vendor                  : LSI
NVDATA Product ID              : RS3UC080
BIOS Version                   : 08.09.00.00
UEFI BSD Version               : 05.00.01.00
FCODE Version                  : N/A
Board Name                     : RS3UC080
Board Assembly                 : XX-XXXXX-XXX (redacted)
Board Tracer Number            : XXXXXXXXXX (redacted)

Finished Processing Commands Successfully.
Exiting SAS3Flash.

3. Power down the system and add the jumper to the TP12 pins of the Intel RS3UC080 card.

4. Boot the system to the EFI shell and navigate to the root of your boot stick.

5. "Dirty" flash the IT mode firmware and wait for it to finish. This way you can verify that the firmware matches your card.
sas3flash.efi -o -f SAS9300_8i_IT.bin -noreset

6. Power down the system and then boot the system back to the EFI shell with the jumper still on TP12.

7. Clear all flash areas of the card.
sas3flash.efi -o -e 7

8. "Dirty" flash the IT mode firmware again and wait for the console output to stop at "Resetting Adapter...".
sas3flash.efi -o -f SAS9300_8i_IT.bin

9. After about 1 minute of wait time, power down the system and remove the jumper from TP12.

10. Boot the system back to the EFI shell and again clear all flash areas.
sas3flash.efi -o -e 7

11. "Clean" flash the IT mode firmware.

11.1 Flash only the IT mode firmware. Use the below command if you do not plan on booting from drives connected to the card.
sas3flash.efi -o -f SAS9300_8i_IT.bin

11.2 Alternatively, flash the IT mode firmware as well as the BIOS/UEFI ROMs. Use the below command if you do plan on booting from drives connected to the card.
Please note that flashing the BIOS/UEFI ROMs can cause significant delays when booting the system or even prevent the system from booting at all.
sas3flash.efi -o -f SAS9300_8i_IT.bin -b mptsas3.rom -b mpt3x64.rom

12. Add the SAS address (without the hyphens displayed in the output of step 2) back to the card.
sas3flash.efi -o -sasadd XXXXXXXXXXXXXXXX

13. Verify that everything was successful.
sas3flash.efi -list

Adapter Selected is a Avago SAS: SAS3008(C0)

Controller Number              : 0
Controller                     : SAS3008(C0)
PCI Address                    : 00:01:00:00
SAS Address                    : XXXXXXX-X-XXXX-XXXX (redacted)
NVDATA Version (Default)       : 0E.01.00.07
NVDATA Version (Persistent)    : 0E.01.00.07
Firmware Product ID            : 0x2221 (IT)
Firmware Version               : 16.00.12.00
NVDATA Vendor                  : LSI     
NVDATA Product ID              : SAS9300-8i      
BIOS Version                   : 08.27.00.00
UEFI BSD Version               : 13.07.00.00
FCODE Version                  : N/A (don't worry, not necessary)
Board Name                     : SAS9300-8i      
Board Assembly                 : N/A (don't worry, not necessary)
Board Tracer Number            : N/A (don't worry, not necessary)

Finished Processing Commands Successfully.
Exiting SAS3Flash.

14. Done, power down the system.
